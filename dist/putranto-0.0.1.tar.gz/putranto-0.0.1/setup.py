from distutils.core import setup
setup(
  name = 'putranto',
  packages = ['putranto'],
  version = '0.0.1',
  description = 'merely my lastname',
  author = 'Evan Hutomo Eka Putranto',
  author_email = 'evanhutomo@gmail.com',
  url = 'https://github.com/evanhutomo/putranto',
  download_url = 'https://github.com/evanhutomo/putranto/tarball/0.0.1',
  keywords = ['testing', 'logging', 'example'], # arbitrary keywords
  classifiers = [],
)